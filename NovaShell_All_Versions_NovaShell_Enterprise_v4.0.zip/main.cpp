// NovaShell Enterprise v4.0 Source Code
