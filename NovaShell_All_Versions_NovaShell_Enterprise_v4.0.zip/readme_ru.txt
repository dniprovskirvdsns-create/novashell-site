Руководство проекта NovaShell v4.0
