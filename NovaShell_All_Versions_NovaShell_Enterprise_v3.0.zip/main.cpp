// NovaShell Enterprise v3.0 Source Code
