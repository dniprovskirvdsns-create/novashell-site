Руководство проекта NovaShell v3.0
