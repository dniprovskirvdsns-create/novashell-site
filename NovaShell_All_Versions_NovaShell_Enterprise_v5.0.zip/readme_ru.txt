Руководство проекта NovaShell v5.0
