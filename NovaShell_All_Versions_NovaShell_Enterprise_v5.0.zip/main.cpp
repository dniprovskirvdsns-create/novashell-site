// NovaShell Enterprise v5.0 Source Code
