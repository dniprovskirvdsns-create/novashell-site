Руководство проекта NovaShell v2.0
