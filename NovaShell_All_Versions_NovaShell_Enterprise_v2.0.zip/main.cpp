// NovaShell Enterprise v2.0 Source Code
