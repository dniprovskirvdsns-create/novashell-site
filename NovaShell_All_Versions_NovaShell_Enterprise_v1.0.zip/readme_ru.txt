Руководство проекта NovaShell v1.0
