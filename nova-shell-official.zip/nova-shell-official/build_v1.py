import os
import zipfile

# Путь к текущей папке проекта
base_dir = os.path.dirname(os.path.abspath(__file__))
exe_path = os.path.join(base_dir, "novashell.exe")
output_zip = os.path.join(base_dir, "NovaShell_Enterprise_v1.0.zip")

print("Подготовка первой версии (v1.0)...")

# Проверяем, существует ли exe-файл
if os.path.exists(exe_path):
    # Читаем байты оригинального файла
    with open(exe_path, "rb") as f:
        exe_data = f.read()
    
    # Модифицируем файл для v1.0 (например, оставляем только базовую часть или добавляем байты метки версии)
    # Здесь можно сделать патч или просто использовать файл для минимальной сборки
    modified_data = exe_data[:len(exe_data) // 2] # Пример: усечение для минимального режима v1.0
    
    # Сохраняем измененный exe во временную папку для первой версии
    v1_folder = os.path.join(base_dir, "NovaShell_v1.0_temp")
    os.makedirs(v1_folder, exist_ok=True)
    
    modified_exe_path = os.path.join(v1_folder, "novashell.exe")
    with open(modified_exe_path, "wb") as f:
        f.write(modified_data)
        
    # Добавляем текстовое описание версии
    with open(os.path.join(v1_folder, "version.txt"), "w", encoding="utf-8") as f:
        f.write("NovaShell Enterprise v1.0 [Minimal Mode]")

    # Запаковываем в архив v1.0
    with zipfile.ZipFile(output_zip, 'w', zipfile.ZIP_DEFLATED) as zipf:
        zipf.write(modified_exe_path, "novashell.exe")
        zipf.write(os.path.join(v1_folder, "version.txt"), "version.txt")
        
    print(f"Готово! Создан уникальный архив первой версии: {output_zip}")
else:
    print("Ошибка: файл novashell.exe не найден в текущей папке!")